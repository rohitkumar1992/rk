$(document).ready(function() {
	$('#owl-carousel').owlCarousel({
	      loop:true,
	      margin:10,
	      autoplay:true, 
	      navigation : false,
	      smartSpeed:450,
	      dots: false,
	      nav:true,
	      navText: ["<img src='images/icon-arrow-prev.png'>","<img src='images/icon-arrow-next.png'>"],
	      responsive:{
	          0:{
	              items:1
	          },
	          600:{
	              items:1
	          },
	          1000:{
	              items:1
	          }
	      }
	  });

	$('#owl-carousel2').owlCarousel({
	      loop:false,
	      margin:10,
	      autoplay:true, 
	      navigation : false,
	      smartSpeed:450,
	      nav:true,
	      responsive:{
	          0:{
	              items:1
	          },
	          600:{
	              items:1
	          },
	          1000:{
	              items:1
	          }
	      }
	  });

	$('#news-slider').owlCarousel({
	      loop:false,
	      margin:10,
	      autoplay:false, 
	      navigation : true,
	      smartSpeed:450,
	      nav:true,
	      navText : ["Previous Post","Next Post"],
	      responsive:{
	          0:{
	              items:1
	          },
	          600:{
	              items:1
	          },
	          1000:{
	              items:1
	          }
	      }
	   });

	$('#cart-slider').owlCarousel({
	      loop:false,
	      margin:0,
	      autoplay:true, 
	      dots: false,
	      navigation : false,
	      smartSpeed:450,
	      thumbs: true,
    	  thumbsPrerendered: true,
	      nav:false,
	      responsive:{
	          0:{
	              items:1
	          },
	          600:{
	              items:1
	          },
	          1000:{
	              items:1
	          }
	      }
	   });

	/*$('#app-slider').owlCarousel({
	      loop:false,
	      margin:30,
	      autoplay:true, 
	      navigation : false,
	      smartSpeed:450,
	      nav:false,
	      responsive:{
	          0:{
	              items:1
	          },
	          600:{
	              items:2
	          },
	          1000:{
	              items:3
	          }
	      }
	   });*/

	$('#news-list').owlCarousel({
	      loop:false,
	      margin:34,
	      autoplay:true, 
	      navigation : false,
	      smartSpeed:450,
	      nav:true,
	      responsive:{
	          0:{
	              items:1
	          },
	          600:{
	              items:2
	          },
	          1000:{
	              items:2
	          }
	      }
	   });
});


$(document).ready(function() {
 
  $(window).scroll(function() {    
    var scroll = $(window).scrollTop();
  
    if (scroll >= 1) {
      $("body").addClass("headerfix");
    } else {
      $("body").removeClass("headerfix");
    }
  });

});

$(document).ready(function() {
  $(function(){
    $(".banner .box.right ul li p.desc").each(function(i){
      len=$(this).text().length;
      if(len>80)
      {
        $(this).text($(this).text().substr(0,128)+'[...]');
      }
    });

    $(".blue-box .box .desc p").each(function(i){
      len=$(this).text().length;
      if(len>30)
      {
        $(this).text($(this).text().substr(0,72)+'[...]');
      }
    });

    $(".team ul li .box .desc p").each(function(i){
      len=$(this).text().length;
      if(len>30)
      {
        $(this).text($(this).text().substr(0,385)+'');
      }
    });

    $(".content.news-list .top .info .desc p, .post-list ul li .box .desc p").each(function(i){
      len=$(this).text().length;
      if(len>30)
      {
        $(this).text($(this).text().substr(0,128)+'[...]');
      }
    });
  });
});


$(document).ready(function() {
	window.pressed = function(){
	    var a = document.getElementById('aa');
	    if(a.value == "")
	    {
	        fileLabel.innerHTML = "No file selected";
	    }
	    else
	    {
	        var theSplit = a.value.split('\\');
	        fileLabel.innerHTML = theSplit[theSplit.length-1];
	    }

	    var a = document.getElementById('aa1');
	    if(a.value == "")
	    {
	        fileLabel1.innerHTML = "No file selected";
	    }
	    else
	    {
	        var theSplit = a.value.split('\\');
	        fileLabel1.innerHTML = theSplit[theSplit.length-1];
	    }

	    var a = document.getElementById('aa2');
	    if(a.value == "")
	    {
	        fileLabel2.innerHTML = "No file selected";
	    }
	    else
	    {
	        var theSplit = a.value.split('\\');
	        fileLabel2.innerHTML = theSplit[theSplit.length-1];
	    }

	    var a = document.getElementById('aa3');
	    if(a.value == "")
	    {
	        fileLabel3.innerHTML = "No file selected";
	    }
	    else
	    {
	        var theSplit = a.value.split('\\');
	        fileLabel3.innerHTML = theSplit[theSplit.length-1];
	    }

	    var a = document.getElementById('aa4');
	    if(a.value == "")
	    {
	        fileLabel4.innerHTML = "No file selected";
	    }
	    else
	    {
	        var theSplit = a.value.split('\\');
	        fileLabel4.innerHTML = theSplit[theSplit.length-1];
	    }
	};
});

$(document).ready(function(){
	//var height = $( window ).height();
	//$('.sdfsdfsdfsd').val(scrollTop	);
	var height = 0;
	
	$('html,body').animate({
		scrollTop: height},
	'slow');
	
	var h =window.location.href;
	var r = h.split('#');
	if(r[1] == 'tab1'){
		$( "ul.nav li:nth-child(1)").addClass("active");
		$('#tab1').addClass("active");
	}else if(r[1] == 'tab2'){
		$( "ul.nav li:nth-child(2)").addClass("active");
		$('#tab2').addClass("active");
	}else if(r[1] == 'tab3'){
		$( "ul.nav li:nth-child(3)").addClass("active");
		$('#tab3').addClass("active");
	}else if(r[1] == 'tab4'){
		$( "ul.nav li:nth-child(4)").addClass("active");
		$('#tab4').addClass("active");
	}else if(r[1] == 'tab5'){
		$( "ul.nav li:nth-child(5)").addClass("active");
		$('#tab5').addClass("active");
	}else if(r[1] == 'tab6'){
		$( "ul.nav li:nth-child(6)").addClass("active");
		$('#tab6').addClass("active");
	}else{
		$( "ul.nav li:nth-child(1)").addClass("active");
		$('#tab1').addClass("active");
	}

});


$(document).ready(function() {
  $('.flexo-tabs ul.nav-tabs li').on('click', function(){
        $(".flexo-tabs ul.nav-tabs").removeClass("in");
    }); 
});

$(document).on("click", function(e) {
	$('a.btn-addcart').on('click', function() {
	  	$('.cart-popup').addClass('show');
	  });
    
    //$('.cart-popup').on('click', function() {
	  //	$('.cart-popup').removeClass('show');
	  //});

	 $('.dropdown-menu.blue-area ul.main-links li').click(function() {
	    $(this).toggleClass('active').siblings().removeClass('active');
	});
  });
$(document).ready(function() {
	$("nav ul.navbar-nav > li.dropdown.m").hover(function () {
	    $(this).toggleClass("open");
	 });
});
$(document).ready(function() {
	$(".footer .dropdown-toggle").click(function () {
	    $('.footer .footer-menu').toggleClass("open");
	 });
});